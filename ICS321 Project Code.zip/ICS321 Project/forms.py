from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, PasswordField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Length, AnyOf

class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")

class registerForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired()])
    fname = StringField("First Name", validators=[DataRequired()])
    lname = StringField("Last Name", validators=[DataRequired()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")

class ShippingForm(FlaskForm):
    country = StringField("Dest. Country")
    city = StringField("Dest. City")
    postal_code = StringField("Dest. Postal Code")
    district = StringField("Dest. District")
    street = StringField("Dest. Street")
    building_number = StringField("Dest. Building Number")
    weight = StringField("Weight")
    width = StringField("Width")
    length = StringField("Length")
    depth = StringField("Depth")
    category = SelectField("Category", choices=["Regular", "Fragile", "Liquid", "Chemical"])
    submit = SubmitField("Ship")

class LocateForm(FlaskForm):
    category = SelectField("Location", choices=["RETAIL", "WAREHOUSE", "FLIGHT", "TRUCK", "DESTINATION", "LOST OR DAMAGED"])
    specialNumber = StringField("Special Number")
    submit = SubmitField("Locate")

class PackagesByCustomerForm(FlaskForm):
    customerId = StringField("Customer ID")
    submit = SubmitField("Get")

class ChangePasswordForm(FlaskForm):
    password = PasswordField("Password")
    submit = SubmitField("Change")
