from flask import Flask
from flask import render_template, redirect, url_for, flash, request
from forms import LoginForm, ShippingForm, LocateForm, PackagesByCustomerForm, ChangePasswordForm, registerForm
import sqlite3
import time

def calcComp(weight, length, width, depth):
    return float(weight)*1+float(length)*1+float(width)*1+float(depth)*1

def calcPrice(weight, length, width, depth):
    return float(weight)*1+float(length)*1+float(width)*1+float(depth)*1

def getPackageDestination(package_id):
    con = sqlite3.connect("database.db")
    cur = con.cursor() 
    sql = f"select destination from package where package_id={package_id};"
    destination = cur.execute(sql).fetchone()[0]
    sql = f"select * from address where address_id={destination};"
    destination = cur.execute(sql).fetchone()
    return destination

def getPackageCategoryCount():
    con = sqlite3.connect("database.db")
    cur = con.cursor() 
    sql = f"select category, count(category) from package group by category;"
    categories = cur.execute(sql).fetchall()
    return categories

def getCustomerInfo(user_id):
    con = sqlite3.connect("database.db")
    cur = con.cursor() 
    sql = f"select * from customer where customer_id='{user_id}';"
    customer = cur.execute(sql)
    return customer.fetchone()

def getEmpInfo(user_id):
    con = sqlite3.connect("database.db")
    cur = con.cursor() 
    sql = f"select * from employee where employee_id='{user_id}';"
    employee = cur.execute(sql)
    return employee.fetchone()

def addUser(user_id, password):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"INSERT INTO User (user_id, password) VALUES ('{user_id}', '{password}');"
    cur.execute(sql)
    con.commit()
    return cur.lastrowid

def addCustomer(customer_id, first_name, last_name):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"INSERT INTO Customer (customer_id, first_name, last_name) VALUES ('{customer_id}', '{first_name}', '{last_name}');"
    cur.execute(sql)
    con.commit()
    return cur.lastrowid

def getAllEmployees():
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = "select * from employee;"
    employees = cur.execute(sql)
    print(employees.fetchall())

def getAllPackages():
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = "select * from Package;"
    packages = cur.execute(sql)
    return packages.fetchall()


def addEmployee(employee_id, first_name, last_name, salary):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"INSERT INTO Employee (employee_id, first_name, last_name, salary) VALUES ('{employee_id}', '{first_name}', '{last_name}', {salary});"
    cur.execute(sql)
    con.commit()

def addAddress(country, city, postal_code, district,street, building_number):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"INSERT INTO Address (country, city, postal_code, district,street, building_number) VALUES ('{country}', '{city}', {postal_code}, '{district}', '{street}', {building_number});"
    cur.execute(sql)
    con.commit()
    return cur.lastrowid


def addPackage(weight, length, width, depth, category, destination, customer_id):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"INSERT INTO Package (weight, length, width, depth, category, destination, customer_id) VALUES ({weight}, {length}, {width}, {depth}, '{category}', {destination}, '{customer_id}');"
    cur.execute(sql)
    con.commit()
    return cur.lastrowid

def locateRetailCenter(package_id, center_id):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"INSERT INTO Location (package_id, time_of_arival, location_type) VALUES ({package_id}, '{time.ctime(time.time())}', 'RETAIL');"
    cur.execute(sql)
    location_id = cur.lastrowid
    sql = f"INSERT INTO Location_Retail_Center (location_id, center_id) VALUES ({location_id}, {center_id});"
    cur.execute(sql)
    con.commit()
    return cur.lastrowid

def locateWareHouse(package_id, warehouse_id):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"INSERT INTO Location (package_id, time_of_arival, location_type) VALUES ({package_id}, '{time.ctime(time.time())}', 'WAREHOUSE');"
    cur.execute(sql)
    location_id = cur.lastrowid
    sql = f"INSERT INTO Location_Warehouse (location_id, warehouse_id) VALUES ({location_id}, {warehouse_id});"
    cur.execute(sql)
    con.commit()
    return cur.lastrowid

def locateTransport(package_id, schedule_number, type):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"INSERT INTO Location (package_id, time_of_arival, location_type) VALUES ({package_id}, '{time.ctime(time.time())}', 'TRANSPORT');"
    cur.execute(sql)
    location_id = cur.lastrowid
    sql = f"INSERT INTO Location_Transport (location_id, schedule_number, type) VALUES ({location_id}, {schedule_number}, '{type}');"
    cur.execute(sql)
    con.commit()
    return cur.lastrowid

def locateDestination(package_id):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"INSERT INTO Location (package_id, time_of_arival, location_type) VALUES ({package_id}, '{time.ctime(time.time())}', 'DESTINATION');"
    cur.execute(sql)
    con.commit()
    return cur.lastrowid

def locatePackage(package_id):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    trace = []
    sql = f"select * from location where package_id={package_id};"
    locations = cur.execute(sql).fetchall()
    for location in locations:
        location_id = location[0]
        time = location[2]
        type = location[3]
        special_number = None;
        if type == "RETAIL":
            sql = f"select * from location_retail_center where location_id={location_id};"
            retail_location = cur.execute(sql).fetchone()
            special_number = retail_location[1]
        elif type == "WAREHOUSE":
            sql = f"select * from location_warehouse where location_id={location_id};"
            warehouse_location = cur.execute(sql).fetchone()
            special_number = warehouse_location[1]
        elif type == "TRANSPORT":
            sql = f"select * from location_transport where location_id={location_id};"
            transport_location = cur.execute(sql).fetchone()
            special_number = transport_location[1]
        trace += [[location_id, time, type, special_number]]
    return trace

def packageStatus(package_id):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"SELECT * FROM Lost_or_Damaged WHERE package_id={package_id};"
    lost_or_damaged = cur.execute(sql).fetchall()
    if len(lost_or_damaged) != 0:
        return "LOST OR DAMAGED"
    locations = locatePackage(package_id)
    if len(locations) == 0:
        return "PLANNED"
    return locatePackage(package_id)[-1][2]



def setLostOrDamaged(package_id):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"SELECT weight, length, width, depth FROM Package WHERE package_id={package_id}"
    package = cur.execute(sql).fetchone()
    sql = f"INSERT INTO Lost_or_Damaged (package_id, compensation) VALUES ({package_id}, {calcComp(package[0],package[1],package[2],package[3])});"
    cur.execute(sql)
    con.commit()
    return cur.lastrowid

def getPackageByCustomer(customer_id):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"SELECT * FROM Package WHERE customer_id='{customer_id}'"
    packages = cur.execute(sql).fetchall()
    return packages

def matchUser(username, password):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"SELECT * FROM User WHERE user_id='{username}'"
    result = cur.execute(sql).fetchone()
    if result == None:
        return None
    if password != result[1]:
        return None
    sql = f"SELECT * FROM Employee WHERE Employee_id='{username}'"
    result = cur.execute(sql).fetchone()
    if result != None:
        return "EMPLOYEE"
    else:
        return "CUSTOMER"

def changePassword(user_id, password):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    sql = f"UPDATE User SET password = '{password}' WHERE user_id='{user_id}';"
    con.execute(sql)
    con.commit()
    

app = Flask(__name__)
app.config["SECRET_KEY"] = "321201946230"

@app.route("/", methods=("GET", "POST"))
@app.route("/login", methods=("GET", "POST"))
def login():
    form = LoginForm()
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        matchStatus = matchUser(username, password)
        if matchStatus == None :
            flash("Username or password is wrong.")
            return redirect(url_for("login"))
        elif matchStatus == "EMPLOYEE":
            return redirect(url_for("employee", user_id=username))
        else:
            return redirect(url_for("customer", user_id=username))
    return render_template("login.html", form=form)

@app.route("/register", methods=("GET", "POST"))
def register():
    form = registerForm()
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        fname = form.fname.data
        lname = form.lname.data
        user = addUser(username, password)
        customer = addCustomer(username, fname, lname)
        return redirect(url_for("login"))
    return render_template("register.html", form=form)


@app.route("/customer/<user_id>")
def customer(user_id):
    return render_template("customer.html", customer_info=getCustomerInfo(user_id), user_id=user_id)

@app.route("/customer/<user_id>/ship", methods=("GET", "POST"))
def customerShip(user_id):
    form = ShippingForm()
    if form.validate_on_submit():
        country = form.country.data
        city = form.city.data
        postal_code = form.postal_code.data
        district = form.district.data
        street = form.street.data
        building_number = form.building_number.data
        weight = form.weight.data
        width = form.width.data
        length = form.length.data
        depth = form.depth.data
        category = form.category.data
        destination = addAddress(country, city, int(postal_code) ,district,street,building_number)
        addPackage(weight, length, width, depth, category, destination, user_id)
        flash("Package shipped and costed $" + str(calcPrice(weight, length, width, depth)))
        return redirect(url_for("customer", user_id=user_id))
    return render_template("shippackage.html", customer_info=getCustomerInfo(user_id), form=form)

@app.route("/customer/<user_id>/mypackages", methods=("GET", "POST"))
def myPackages(user_id):
    packages = getPackageByCustomer(user_id)
    return render_template("myPackages.html", user_id=user_id, packages=packages)

@app.route("/user/<user_id>/changePassword", methods=("GET", "POST"))
def changePasswordView(user_id):
    form = ChangePasswordForm()
    if form.validate_on_submit():
        password = form.password.data
        changePassword(user_id, password)
        flash("Password changed!")
        return redirect(url_for("/login"))
    return render_template("changepassword.html", user_id=user_id, form=form)


@app.route("/trackpackage/<package_id>", methods=("GET", "POST"))
def trackPackage(package_id):
    destination = getPackageDestination(package_id)
    locations = locatePackage(package_id)
    return render_template("trackpackage.html", package_id=package_id, destination = destination, locations=locations, status=packageStatus(package_id))

@app.route("/employee/<user_id>")
def employee(user_id):
    return render_template("employee.html", employee_info=getEmpInfo(user_id), user_id=user_id)


@app.route("/employee/<user_id>/packages")
def allPackages(user_id):
    return render_template("allpackages.html", packages=getAllPackages(), user_id=user_id)

@app.route("/employee/<user_id>/getCustomerPackages", methods=("GET", "POST"))
def getCustomerPackages(user_id):
    form = PackagesByCustomerForm()
    if form.validate_on_submit():
        customer_id = form.customerId.data
        return redirect(url_for("packagesByCust", user_id=user_id, customer_id=customer_id))
    return render_template("getCustomer.html", form=form, user_id=user_id)


@app.route("/employee/<user_id>/packages/<customer_id>")
def packagesByCust(user_id, customer_id):
    return render_template("packagesbycust.html", packages=getPackageByCustomer(customer_id), user_id=user_id, customer_id=customer_id)

@app.route("/employee/<user_id>/categoriesreport")
def categoriesReport(user_id):
    return render_template("categories.html", categories=getPackageCategoryCount())



@app.route("/employee/<user_id>/locate/<package_id>", methods=("GET", "POST"))
def packageLocation(user_id, package_id):
    form = LocateForm()
    if form.validate_on_submit():
        category = form.category.data
        specialNumber = form.specialNumber.data
        # ["RETAIL", "WAREHOUSE", "FLIGHT", "TRUCK", "DESTINATION", "LOST OR DAMAGED"]
        if category == "DESTINATION":
            locateDestination(package_id)
        elif category == "LOST OR DAMAGED":
            setLostOrDamaged(package_id)
        elif category == "TRUCK":
            locateTransport(package_id, specialNumber, "TRUCK")
        elif category == "FLIGHT":
            locateTransport(package_id, specialNumber, "FLIGHT")
        elif category == "WAREHOUSE":
            locateWareHouse(package_id, specialNumber)
        elif category == "RETAIL":
            locateRetailCenter(package_id, specialNumber)
        flash("Package Located")
        return redirect(url_for("allPackages", user_id=user_id))
    return render_template("locatePackage.html", form=form)




if __name__ == '__main__':
    app.run(debug=False)
